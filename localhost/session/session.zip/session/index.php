<?
session_start();

if('POST'==$_SERVER['REQUEST_METHOD']):
	include('post.php');
endif;

$count = $_SESSION['count'] + 1;
$_SESSION['count'] = $count;
$_SESSION['last'] = strftime("%c");
?>
<h1>Сессия</h1>

<? 
if($_SESSION['user']):
?>
Здравствуйте, <?= $_SESSION['user'] ?>
<?
else:
?>
Вы не авторизованы, авторизуйтесь!
<?
endif;
?>
<p>
Вы были здесь <?= $count ?> раз.

<hr>
<form method=POST>
<label>Имя пользователя<br>
  <input type=text name=user required>
</label>
<p>
<label>Пароль<br>
  <input type=password name=password required>
</label>
<p>
<input type=submit value="Авторизоваться!">
</form>
