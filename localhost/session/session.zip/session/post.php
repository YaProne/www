<?
$Users=Array(
	'vasya'=>'1', 
	'petya'=>'2', 
	'kolya'=>'3'
);
if($Users[$_POST['user']] == $_POST['password']):
  $_SESSION['user'] = $_POST['user'];
  $_SESSION['logon'] = strftime("%c");
else:
  $_SESSION['user'] = '';
endif;

// header('HTTP/1.0 301 Redirect');
header('Location: ./');
?>
